package com.raptors.manufacture.api.coreservicemanufacture.repository;

import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Type;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManufactureRepository extends CrudRepository<Manufacturer,String> {
}
