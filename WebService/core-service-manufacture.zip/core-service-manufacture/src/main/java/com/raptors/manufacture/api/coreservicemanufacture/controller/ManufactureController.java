package com.raptors.manufacture.api.coreservicemanufacture.controller;

import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Type;
import com.raptors.manufacture.api.coreservicemanufacture.domain.TypeManufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.repository.TypeManufacturerRepository;
import com.raptors.manufacture.api.coreservicemanufacture.service.ManufactureService;
import com.raptors.manufacture.api.coreservicemanufacture.service.TypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "manufacture")
@Api(value = "manufacture",description = "operations")
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class ManufactureController {

    private final TypeService typeService;

    private final ManufactureService manufactureService;

    private final TypeManufacturerRepository typeManufacturerRepository;

    @ApiResponses(value = {
            @ApiResponse(code=200,message = "Success"),
            @ApiResponse(code=401,message = "Unauthorized"),
            @ApiResponse(code=403,message = "Forbiden"),
            @ApiResponse(code=404,message = "Not Found")
    })
    @ApiOperation(value="returns car details")
    @RequestMapping(value = "typeFindAll",method = RequestMethod.GET)
    public List<Type> typeFindAll(){

        List<Type> typeList = typeService.findAll();

        return typeList;
    }


    @ApiResponses(value = {
            @ApiResponse(code=200,message = "Success"),
            @ApiResponse(code=401,message = "Unauthorized"),
            @ApiResponse(code=403,message = "Forbiden"),
            @ApiResponse(code=404,message = "Not Found")
    })
    @ApiOperation(value="returns car details")
    @RequestMapping(value = "manufactureFindAll",method = RequestMethod.GET)
    public List<Manufacturer> manufactureFindAll(){

        List<Manufacturer> manufactureList = manufactureService.findAll();

        return manufactureList;
    }

    @ApiResponses(value = {
            @ApiResponse(code=200,message = "Success"),
            @ApiResponse(code=401,message = "Unauthorized"),
            @ApiResponse(code=403,message = "Forbiden"),
            @ApiResponse(code=404,message = "Not Found")
    })
    @ApiOperation(value="returns manufacture details")
    @RequestMapping(value = "findOne",method = RequestMethod.GET)
    public String findOne(@RequestParam int id){

        String type = typeService.findone(id);
        return type;
    }


    @ApiResponses(value = {
            @ApiResponse(code=200,message = "Success"),
            @ApiResponse(code=401,message = "Unauthorized"),
            @ApiResponse(code=403,message = "Forbiden"),
            @ApiResponse(code=404,message = "Not Found")
    })
    @ApiOperation(value="returns manufacture details")
    @RequestMapping(value = "manufacturerId",method = RequestMethod.GET)
    public List<TypeManufacturer> findManufacturer(@RequestParam int id){
        List<TypeManufacturer> manufacturerId = typeManufacturerRepository.findManufacturerId(id);
         return manufacturerId;
    }




}
