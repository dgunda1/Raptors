package com.raptors.manufacture.api.coreservicemanufacture.service;


import com.google.common.collect.Lists;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.TypeManufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.repository.ManufactureRepository;
import com.raptors.manufacture.api.coreservicemanufacture.repository.TypeManufacturerRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Data
@RequiredArgsConstructor(onConstructor = @_(@Autowired))


public class TypeManufacturerService {

    private final TypeManufacturerRepository typeManufacturerRepository;

    public List<TypeManufacturer> findAll(int id){

        return typeManufacturerRepository.findManufacturerId(id);

    }

}
