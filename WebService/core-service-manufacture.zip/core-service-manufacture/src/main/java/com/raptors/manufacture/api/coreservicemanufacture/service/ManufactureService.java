package com.raptors.manufacture.api.coreservicemanufacture.service;

import com.google.common.collect.Lists;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Type;
import com.raptors.manufacture.api.coreservicemanufacture.repository.ManufactureRepository;
import com.raptors.manufacture.api.coreservicemanufacture.repository.TypeRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Data
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class ManufactureService {

    private final ManufactureRepository manufactureRepository;

    public List<Manufacturer> findAll(){

        return Lists.newArrayList(manufactureRepository.findAll());

    }
}
