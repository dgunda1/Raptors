package com.raptors.manufacture.api.coreservicemanufacture.service;

import com.google.common.collect.Lists;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Type;
import com.raptors.manufacture.api.coreservicemanufacture.repository.TypeRepository;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Data
@RequiredArgsConstructor(onConstructor = @_(@Autowired))
public class TypeService {

    private final TypeRepository typeRepository;

    public List<Type> findAll(){

        return Lists.newArrayList(typeRepository.findAll());

    }

    public String findone(int id){

        Type type = typeRepository.findId(id);

        return type.getType();

    }
}
