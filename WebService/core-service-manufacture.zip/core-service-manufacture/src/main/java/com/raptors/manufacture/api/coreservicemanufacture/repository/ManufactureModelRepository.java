package com.raptors.manufacture.api.coreservicemanufacture.repository;

import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.ManufacturerModel;
import com.raptors.manufacture.api.coreservicemanufacture.domain.TypeManufacturer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ManufactureModelRepository extends CrudRepository<ManufacturerModel,String> {

    @Query("SELECT c FROM ManufacturerModel c WHERE c.manufactureId =?1")
    ManufacturerModel findModel(int id);
}
