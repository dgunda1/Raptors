package com.raptors.manufacture.api.coreservicemanufacture.repository;

import com.raptors.manufacture.api.coreservicemanufacture.domain.Type;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TypeRepository extends CrudRepository<Type,String> {


    @Query("SELECT c FROM Type c WHERE c.id =?1")
    Type findId(int id);
}
