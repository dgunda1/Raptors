package com.raptors.manufacture.api.coreservicemanufacture.repository;

import com.raptors.manufacture.api.coreservicemanufacture.domain.Manufacturer;
import com.raptors.manufacture.api.coreservicemanufacture.domain.Type;
import com.raptors.manufacture.api.coreservicemanufacture.domain.TypeManufacturer;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface TypeManufacturerRepository extends CrudRepository<TypeManufacturer,String> {

    @Query("SELECT c FROM TypeManufacturer c WHERE c.typeId =?1")
    List<TypeManufacturer> findManufacturerId(int id);

}
